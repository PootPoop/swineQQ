https://docs.google.com/document/d/1hOTe7ppLG4LkfsR1GpswXr3-nWNQb9-iNpmtlvgo4SY/edit?usp=sharing
